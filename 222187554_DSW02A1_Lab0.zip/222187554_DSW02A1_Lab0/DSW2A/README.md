# DSW2A
DSW Labs

<!--node and npm versions:
PS C:\Users\User\OneDrive\Documents\BIT\DSW2A\222187554_DSW02A1_Lab0\DSW2A> node -v
v24.13.1
PS C:\Users\User\OneDrive\Documents\BIT\DSW2A\222187554_DSW02A1_Lab0\DSW2A> npm -v
11.6.2-->

<!--hello-node.js run output:
C:\Program Files\nodejs\node.exe .\hello-node.js-->

<!--github initial push:
User@DESKTOP-870STAJ MINGW64 ~/OneDrive/Documents/BIT/DSW2A/222187554_DSW02A1_Lab0/DSW2A (main)
$ git commit -m "Initial Push"
On branch main
Your branch is up to date with 'origin/main'.

Changes not staged for commit:
  (use "git add <file>..." to update what will be committed)
  (use "git restore <file>..." to discard changes in working directory)
        modified:   README.md

Untracked files:
  (use "git add <file>..." to include in what will be committed)
        Screenshot 2026-02-18 200928.png
        hello-node.js
        index.html

no changes added to commit (use "git add" and/or "git commit -a")-->